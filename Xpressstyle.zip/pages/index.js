import React from "react";

export default function Home() {
  const rabatter = [
    { id: 1, navn: "10% hos NLY Man", link: "https://nlyman.com" },
    { id: 2, navn: "20% hos Ferner Jacobsen", link: "https://fernerjacobsen.no" },
    { id: 3, navn: "15% hos Care of Carl", link: "https://careofcarl.no" },
  ];

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-md">
        <h1 className="text-2xl font-bold mb-4 text-center">Siste rabatter</h1>
        <ul className="space-y-3">
          {rabatter.map((rabatt) => (
            <li key={rabatt.id} className="p-4 border rounded-lg shadow-sm bg-gray-50">
              <a
                href={rabatt.link}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 font-semibold hover:underline"
              >
                {rabatt.navn}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
